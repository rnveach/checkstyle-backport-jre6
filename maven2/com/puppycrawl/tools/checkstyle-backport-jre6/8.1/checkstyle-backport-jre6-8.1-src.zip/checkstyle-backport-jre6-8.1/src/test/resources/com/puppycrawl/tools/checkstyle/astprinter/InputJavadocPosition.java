public class InputJavadocPosition {
    void method() {
	/**
	This is a method
	@return void
	<html
	*/
    }
}
