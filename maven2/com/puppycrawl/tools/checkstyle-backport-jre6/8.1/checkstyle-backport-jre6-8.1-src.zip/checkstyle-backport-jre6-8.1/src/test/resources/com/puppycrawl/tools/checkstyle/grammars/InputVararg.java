package com.puppycrawl.tools.checkstyle.grammars;

/**
 * Input for vararg test.
 */
public class InputVararg
{
    public static void main(String... args)
    {
    }
}
