//start line index in expected file is 2
package com.puppycrawl.tools.checkstyle.grammars;

public interface InputRegressionJava8Interface1 {
    default void m() {}
}
