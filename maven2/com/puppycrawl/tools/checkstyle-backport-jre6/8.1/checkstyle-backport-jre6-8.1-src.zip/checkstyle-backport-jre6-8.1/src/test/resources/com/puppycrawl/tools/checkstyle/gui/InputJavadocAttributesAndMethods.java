/**
* class javadoc
*/
class InputJavadocAttributesAndMethods {

    /** attribute javadoc*/
    int attribute;

    /**
    * method javadoc
    */
    public void method() { 
        /* just comment */
    }

}
