package com.testing.packagediffdirectory;

public class InputPackageDeclarationDiffDirectory {
    public String value;

    private void get(){
    }
}
