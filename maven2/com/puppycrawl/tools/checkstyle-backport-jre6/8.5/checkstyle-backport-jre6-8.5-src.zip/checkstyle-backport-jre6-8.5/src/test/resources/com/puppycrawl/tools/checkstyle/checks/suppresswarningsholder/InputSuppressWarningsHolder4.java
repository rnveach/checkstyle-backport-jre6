package com.puppycrawl.tools.checkstyle.checks.suppresswarningsholder;

public class InputSuppressWarningsHolder4 {

    @CustomAnnotation()
    int a;
    
}
@interface CustomAnnotation {
}
