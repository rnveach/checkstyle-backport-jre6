package com.puppycrawl.tools.checkstyle.xpath.xpathmapper;

public interface InputXpathMapperInterface {
    int sum(int a, int b);
    void init(String someVariable, int age);
    String getName();
    void delete();
}
