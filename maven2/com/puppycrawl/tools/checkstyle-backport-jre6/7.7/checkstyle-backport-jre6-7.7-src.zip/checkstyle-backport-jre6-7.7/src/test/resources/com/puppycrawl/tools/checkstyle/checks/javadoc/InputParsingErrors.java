package com.puppycrawl.tools.checkstyle.checks.javadoc;

/**
 * <unclosedTag>
 */
class InputParsingErrors {
    /**
     * <img src="singletonTag"/></img>
     */
    void singletonTag() {
    }
}
