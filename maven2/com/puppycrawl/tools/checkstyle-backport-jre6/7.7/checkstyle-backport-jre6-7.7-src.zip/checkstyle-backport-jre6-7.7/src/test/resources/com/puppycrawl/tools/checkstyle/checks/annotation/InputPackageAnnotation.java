package com.puppycrawl.tools.checkstyle.checks.annotation;

@Deprecated
public class InputPackageAnnotation {
	
}
