package com.puppycrawl.tools.checkstyle.checks.design;

import java.io.Serializable;
/*input file*/
public abstract class InputHideUtilityClassConstructor3041574_1 implements Serializable {
    private static final long serialVersionUID = 1L;

}