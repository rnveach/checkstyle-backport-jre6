package com.puppycrawl.tools.checkstyle.filters.suppresswithplaintextcommentfilter;

public class InputSuppressWithPlainTextCommentFilterWithDefaultCfg {
    // CHECKSTYLE:OFF
    //	has tab here

    // CHECKSTYLE:ON
    //	has tab here

	private int a; // CHECKSTYLE:OFF
    // CHECKSTYLE:ON
}
