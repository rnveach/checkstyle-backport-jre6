package com.puppycrawl.tools.checkstyle.checks.javadoc.abstracttypeaware;

public class InputAbstractTypeAwareLoadErrors
{
    /**
     * aasdf
     * @throws InvalidExceptionName exception that cannot be loaded
     */
    void method() {}
}
