package com.puppycrawl.tools.checkstyle.utils.blockcommentposition;


public enum InputBlockCommentPositionOnEnumMember {
    /**
     * I'm a javadoc
     */
    A,
    /**
     * I'm a javadoc
     */
    @Deprecated
    B,
}
