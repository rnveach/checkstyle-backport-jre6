package com.puppycrawl.tools.checkstyle.checks.annotation.annotationusestyle;

@interface InputAnnotationUseStyleCustomAnnotation {
}
