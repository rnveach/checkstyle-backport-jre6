package com.puppycrawl.tools.checkstyle.checks.whitespace.singlespaceseparator;

public class InputSingleSpaceSeparatorChildNodes {
    int j = 0;
    int i = 1  + j;
}
