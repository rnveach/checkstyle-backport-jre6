package com.puppycrawl.tools.checkstyle.checks.imports.redundantimport;

import static java.util.Arrays.asList;

import java.util.List;

public class InputRedundantImportWithoutWarnings {
    private static final List<String> CONSTANTS = asList("a", "b");
}
