package com.puppycrawl.tools.checkstyle.checks.header.regexpheader;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * blah blah
 * @see foo
 */
public class InputRegexpHeaderMulti2
{
}
