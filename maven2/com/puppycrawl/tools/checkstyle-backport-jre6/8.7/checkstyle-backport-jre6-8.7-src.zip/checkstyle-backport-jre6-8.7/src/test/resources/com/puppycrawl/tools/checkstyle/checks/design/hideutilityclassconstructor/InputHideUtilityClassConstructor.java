package com.puppycrawl.tools.checkstyle.checks.design.hideutilityclassconstructor;

public class InputHideUtilityClassConstructor {
    
    protected InputHideUtilityClassConstructor() {
        //does nothing
    }
}
