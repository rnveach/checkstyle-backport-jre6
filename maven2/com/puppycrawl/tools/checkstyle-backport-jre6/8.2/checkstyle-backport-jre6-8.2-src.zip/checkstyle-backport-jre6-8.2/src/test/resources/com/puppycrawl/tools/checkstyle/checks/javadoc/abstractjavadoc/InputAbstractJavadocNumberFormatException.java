package com.puppycrawl.tools.checkstyle.checks.javadoc.abstractjavadoc;

/** <ul><li>a' {@link EntityEntry} (by way of {@link #;}</li></ul> */
class InputAbstractJavadocNumberFormatException{}
