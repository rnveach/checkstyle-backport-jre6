package com.puppycrawl.tools.checkstyle.checks.whitespace.emptylineseparator;

public class InputEmptyLineSeparatorMultipleFieldsInClass
{
    int first;
    int second;
}
