package com.puppycrawl.tools.checkstyle.utils.blockcommentposition;

/**
 * I'm a javadoc
 */
public enum InputBlockCommentPositionOnEnum {
}

/**
 * I'm a javadoc
 */
enum BlockCommentPositionOnEnumInput1 {
}

/**
 * I'm a javadoc
 */
@Deprecated
enum BlockCommentPositionOnEnumInput2{

}
