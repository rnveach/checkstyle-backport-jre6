package com.puppycrawl.tools.checkstyle.checks.whitespace.genericwhitespace;

import java.util.List;

public class InputGenericWhitespaceList
{
    public List<List<String>[]> listOfListOFArrays;
}