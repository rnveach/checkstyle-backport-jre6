package com.puppycrawl.tools.checkstyle.checks.coding.illegaltype;

public class InputIllegalTypeGregorianCalendar
{
    class SubCalendar {
        
    }
}
