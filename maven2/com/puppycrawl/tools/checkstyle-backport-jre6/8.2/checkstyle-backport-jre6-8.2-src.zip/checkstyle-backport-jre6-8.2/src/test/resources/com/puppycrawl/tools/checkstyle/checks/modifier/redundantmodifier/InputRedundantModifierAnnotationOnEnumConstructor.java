package com.puppycrawl.tools.checkstyle.checks.modifier.redundantmodifier;

public enum InputRedundantModifierAnnotationOnEnumConstructor {
    ;

    @SuppressWarnings("checkstyle:name")
    InputRedundantModifierAnnotationOnEnumConstructor() {
    }
}
enum InputRedundantModifierAnnotationOnEnumConstructor2 {
    ;

    @SuppressWarnings("checkstyle:name")
    private InputRedundantModifierAnnotationOnEnumConstructor2() {
    }
}
