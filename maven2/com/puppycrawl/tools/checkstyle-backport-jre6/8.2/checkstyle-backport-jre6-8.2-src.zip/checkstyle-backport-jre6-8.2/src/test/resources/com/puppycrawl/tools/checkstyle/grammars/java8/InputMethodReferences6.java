package com.puppycrawl.tools.checkstyle.grammars.java8;


public final class InputMethodReferences6 {

    public void testMethod() {

        @SuppressWarnings("unused")
        class MyClass {
            public int doSomething() {
                return 0;
            }
        }

    }

}
