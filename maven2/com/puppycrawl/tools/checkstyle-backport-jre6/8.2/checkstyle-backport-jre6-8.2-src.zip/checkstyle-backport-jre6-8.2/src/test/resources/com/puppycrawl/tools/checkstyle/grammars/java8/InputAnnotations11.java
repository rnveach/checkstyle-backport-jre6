package com.puppycrawl.tools.checkstyle.grammars.java8;


class InputAnnotations11 <@Nullable T> {
}
