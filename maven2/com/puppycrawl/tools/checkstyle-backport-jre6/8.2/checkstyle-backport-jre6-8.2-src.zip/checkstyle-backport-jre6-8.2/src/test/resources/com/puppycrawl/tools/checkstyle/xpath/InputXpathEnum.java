package com.puppycrawl.tools.checkstyle.xpath;

public enum InputXpathEnum {
    ONE,
    TWO,
    THREE
}
