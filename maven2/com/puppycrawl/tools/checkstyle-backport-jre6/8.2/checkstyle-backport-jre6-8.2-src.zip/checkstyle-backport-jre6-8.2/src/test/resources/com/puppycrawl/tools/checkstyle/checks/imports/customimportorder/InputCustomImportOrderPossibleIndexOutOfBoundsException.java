package com.puppycrawl.tools.checkstyle.checks.imports.customimportorder;

import javax.xml.transform.Source;

import org.w3c.dom.Node;

class InputCustomImportOrderPossibleIndexOutOfBoundsException {}
