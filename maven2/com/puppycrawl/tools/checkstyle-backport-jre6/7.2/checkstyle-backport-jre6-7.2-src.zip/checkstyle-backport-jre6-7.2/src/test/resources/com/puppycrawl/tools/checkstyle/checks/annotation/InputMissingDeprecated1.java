package com.puppycrawl.tools.checkstyle.checks.annotation;

import java.lang.annotation.Inherited;
/**
 * 
 * @author idubinin
 *@deprecated
 *@deprecated
 *stuff
 *stuff
 */
public class InputMissingDeprecated1
{
    
}
