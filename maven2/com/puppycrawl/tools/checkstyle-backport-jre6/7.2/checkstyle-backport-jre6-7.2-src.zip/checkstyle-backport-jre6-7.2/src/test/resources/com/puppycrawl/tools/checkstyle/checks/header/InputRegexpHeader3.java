package com.puppycrawl.tools.checkstyle.checks.header;

import java.awt.*;

public class InputRegexpHeader3
{
}
