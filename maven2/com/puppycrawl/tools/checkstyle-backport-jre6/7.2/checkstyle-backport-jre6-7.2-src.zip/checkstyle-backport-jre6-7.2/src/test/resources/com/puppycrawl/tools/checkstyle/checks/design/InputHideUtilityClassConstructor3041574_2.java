package com.puppycrawl.tools.checkstyle.checks.design;

import java.io.Serializable;
/*input file*/
public class InputHideUtilityClassConstructor3041574_2 implements Serializable {
    private static final long serialVersionUID = 1L;

}