package com.puppycrawl.tools.checkstyle.grammars;

public class InputLineCommentAtTheEndOfFile
{
} // EOF on this line