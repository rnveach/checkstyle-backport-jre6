package com.puppycrawl.tools.checkstyle.checks;

public class InputSuppressWarningsHolder4 {

    @com.puppycrawl.tools.checkstyle.checks.CustomAnnotation()
    int a;
    
}
@interface CustomAnnotation {
}
