package com.puppycrawl.tools.checkstyle.checks.sizes.outertypenumber;

/**Contains empty inner class for OuterTypeNumberCheckTest*/
public class InputOuterTypeNumberEmptyInner {

    /** Just empty inner class*/
    private class InnerClass {
        // Do nothing
    }
}
