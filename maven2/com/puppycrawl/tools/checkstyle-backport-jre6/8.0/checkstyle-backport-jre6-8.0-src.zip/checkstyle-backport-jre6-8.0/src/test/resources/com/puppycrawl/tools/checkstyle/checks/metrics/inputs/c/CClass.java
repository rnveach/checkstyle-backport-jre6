package com.puppycrawl.tools.checkstyle.checks.metrics.inputs.c;

public class CClass {
}
