/** Comment */ package com.puppycrawl.tools.checkstyle.checks.indentation.indentation;//indent:0 exp:>=0

public class InputIndentationPackageDeclaration3 {}//indent:0 exp:0
