package com.puppycrawl.tools.checkstyle.checks.header.regexpheader;


/**
 */
public class InputRegexpHeaderSmallHeader {}
