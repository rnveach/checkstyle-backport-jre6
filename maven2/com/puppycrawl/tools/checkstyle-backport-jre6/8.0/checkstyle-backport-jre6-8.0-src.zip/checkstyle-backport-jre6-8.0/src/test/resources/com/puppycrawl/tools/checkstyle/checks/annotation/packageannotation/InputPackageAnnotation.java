package com.puppycrawl.tools.checkstyle.checks.annotation.packageannotation;

@Deprecated
public class InputPackageAnnotation {
	
}
