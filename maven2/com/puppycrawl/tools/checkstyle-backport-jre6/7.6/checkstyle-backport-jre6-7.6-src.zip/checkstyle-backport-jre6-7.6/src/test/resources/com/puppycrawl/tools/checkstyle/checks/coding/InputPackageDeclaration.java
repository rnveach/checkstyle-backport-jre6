package com.puppycrawl.tools.checkstyle.checks.coding;

class InputPackageDeclaration {
    public String value;
    
    private void get(){
    }
}