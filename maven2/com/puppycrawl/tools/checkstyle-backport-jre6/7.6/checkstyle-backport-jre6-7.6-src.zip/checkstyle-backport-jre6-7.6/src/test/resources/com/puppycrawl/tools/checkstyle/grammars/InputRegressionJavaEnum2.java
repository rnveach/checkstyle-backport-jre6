package com.puppycrawl.tools.checkstyle.grammars;

public enum InputRegressionJavaEnum2 {
}