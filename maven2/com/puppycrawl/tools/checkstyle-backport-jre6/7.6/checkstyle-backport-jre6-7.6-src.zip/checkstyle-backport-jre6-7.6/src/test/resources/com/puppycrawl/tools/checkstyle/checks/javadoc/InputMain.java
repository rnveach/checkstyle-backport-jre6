package com.puppycrawl.tools.checkstyle.checks.javadoc;
/** Javadoc */
public class InputMain {
}
