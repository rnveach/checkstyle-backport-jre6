package com.puppycrawl.tools.checkstyle.grammars;


import java.util.Collection;
import java.util.List;

public interface InputRegressionJavaInterface1 extends List, Collection {
}
