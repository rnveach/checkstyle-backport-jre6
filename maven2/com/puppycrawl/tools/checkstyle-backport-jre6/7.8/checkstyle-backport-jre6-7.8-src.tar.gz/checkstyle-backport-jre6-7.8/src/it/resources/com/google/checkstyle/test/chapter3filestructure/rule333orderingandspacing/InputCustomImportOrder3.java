package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

import static java.awt.Button.ABORT;
import java.awt.Dialog; //warn
import static javax.swing.WindowConstants.*; //warn

import com.google.checkstyle.test.chapter2filebasic.rule21filename.*; //warn
import com.google.common.reflect.*; //warn
import com.sun.xml.internal.xsom.impl.scd.Iterators; //warn
import java.io.File;
import static java.io.File.createTempFile; //warn
import java.util.StringTokenizer;
import java.util.*; //warn
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.*; //warn

public class InputCustomImportOrder3 {
}
