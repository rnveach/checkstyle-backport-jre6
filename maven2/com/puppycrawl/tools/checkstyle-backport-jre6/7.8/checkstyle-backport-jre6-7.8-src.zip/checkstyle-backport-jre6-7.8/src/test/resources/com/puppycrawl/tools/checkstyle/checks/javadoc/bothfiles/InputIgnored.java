package com.puppycrawl.tools.checkstyle.checks.javadoc.bothfiles;

class InputIgnored
{
}
