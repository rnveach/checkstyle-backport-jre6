package com.puppycrawl.tools.checkstyle.checks.metrics.inputs.a.ab;

public class ABClass {
}
