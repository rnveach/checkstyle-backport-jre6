package com.puppycrawl.tools.checkstyle.checks.imports;
import static java.awt.Button.ABORT;
import static javax.swing.WindowConstants.*;
import static java.io.File.createTempFile;
import java.util.*;
import java.util.StringTokenizer;
import com.puppycrawl.tools.*;
import com.*;
import org.apache.commons.beanutils.*;

public class InputCustomImportOrder_NoSeparator {
}
