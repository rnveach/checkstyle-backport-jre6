package com.puppycrawl.tools.checkstyle.checks.design.hideutilityclassconstructor;

import java.io.Serializable;
/*input file*/
public class InputHideUtilityClassConstructorSerializable implements Serializable {
    private static final long serialVersionUID = 1L;

}
