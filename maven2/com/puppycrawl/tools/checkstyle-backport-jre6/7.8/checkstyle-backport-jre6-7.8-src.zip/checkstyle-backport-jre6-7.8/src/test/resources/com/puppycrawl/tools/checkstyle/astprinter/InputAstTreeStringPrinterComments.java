package com.puppycrawl.tools.checkstyle;

/**my class*/
class InputAstTreeStringPrinterComments {
	// no code
}