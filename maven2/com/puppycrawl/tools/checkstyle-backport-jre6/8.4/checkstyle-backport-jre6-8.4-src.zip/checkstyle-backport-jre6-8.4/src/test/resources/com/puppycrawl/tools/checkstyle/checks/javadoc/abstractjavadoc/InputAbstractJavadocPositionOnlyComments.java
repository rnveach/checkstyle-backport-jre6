package com.puppycrawl.tools.checkstyle.checks.javadoc.abstractjavadoc;
/** Javadoc for import */
import java.io.Serializable;
