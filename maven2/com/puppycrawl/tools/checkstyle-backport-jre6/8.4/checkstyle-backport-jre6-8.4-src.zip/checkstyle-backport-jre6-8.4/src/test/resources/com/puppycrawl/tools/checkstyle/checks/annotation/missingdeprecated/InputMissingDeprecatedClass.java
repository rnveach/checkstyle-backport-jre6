package com.puppycrawl.tools.checkstyle.checks.annotation.missingdeprecated;

import java.lang.annotation.Inherited;
/**
 * 
 * @author idubinin
 *@deprecated
 *@deprecated
 *stuff
 *stuff
 */
public class InputMissingDeprecatedClass
{
    
}
