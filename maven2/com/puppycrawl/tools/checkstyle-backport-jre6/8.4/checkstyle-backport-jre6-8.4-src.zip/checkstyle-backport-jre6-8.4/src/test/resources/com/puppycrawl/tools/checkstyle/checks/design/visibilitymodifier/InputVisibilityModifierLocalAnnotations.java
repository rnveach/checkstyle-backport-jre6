package com.puppycrawl.tools.checkstyle.checks.design.visibilitymodifier;

public class InputVisibilityModifierLocalAnnotations
{
    public @interface Rule {
        
    }

    public @interface ClassRule {

    }
}
