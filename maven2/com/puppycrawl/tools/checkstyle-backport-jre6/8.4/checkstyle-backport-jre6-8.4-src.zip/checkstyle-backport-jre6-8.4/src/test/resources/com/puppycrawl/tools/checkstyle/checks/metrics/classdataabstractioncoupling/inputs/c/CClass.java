package com.puppycrawl.tools.checkstyle.checks.metrics.classdataabstractioncoupling.inputs.c;

public class CClass {
}
