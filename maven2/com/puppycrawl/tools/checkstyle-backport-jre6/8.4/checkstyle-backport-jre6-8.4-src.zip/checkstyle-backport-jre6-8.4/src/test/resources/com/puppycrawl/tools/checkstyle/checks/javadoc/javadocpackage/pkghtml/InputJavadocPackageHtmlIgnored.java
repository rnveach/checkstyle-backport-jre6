package com.puppycrawl.tools.checkstyle.checks.javadoc.pkghtml;

class InputJavadocPackageHtmlIgnored
{
}
