package com.puppycrawl.tools.checkstyle.checks.javadoc.abstractjavadoc;
/** Javadoc */
public class InputAbstractJavadocMain {
}
