public class InputMethodCount5 {
    void method1() {
    }

    private @interface Generates {}

    void method2() {
    }
}
