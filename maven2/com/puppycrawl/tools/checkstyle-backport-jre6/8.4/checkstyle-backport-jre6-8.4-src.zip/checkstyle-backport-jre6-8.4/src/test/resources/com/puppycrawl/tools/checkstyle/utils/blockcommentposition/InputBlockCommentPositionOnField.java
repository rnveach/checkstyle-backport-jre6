package com.puppycrawl.tools.checkstyle.utils.blockcommentposition;

public class InputBlockCommentPositionOnField {
    /**
     * I'm a javadoc
     */
    int a;

    /**
     * I'm a javadoc
     */
    private int b;

    /**
     * I'm a javadoc
     */
    @Deprecated
    int c;
}
