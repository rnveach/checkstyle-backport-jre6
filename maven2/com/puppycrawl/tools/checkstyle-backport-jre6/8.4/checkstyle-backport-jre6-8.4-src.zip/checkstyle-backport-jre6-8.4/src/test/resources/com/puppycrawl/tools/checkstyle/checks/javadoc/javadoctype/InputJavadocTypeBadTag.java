package com.puppycrawl.tools.checkstyle.checks.javadoc.javadoctype;

/**
 * The following is a bad tag.
 * @mytag Hello
 */
public class InputJavadocTypeBadTag
{
}
