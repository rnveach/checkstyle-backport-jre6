package com.puppycrawl.tools.checkstyle.ant;

public final class InputCheckstyleAntTaskFlawless {
    private String foo = "A short line";
}
