package com.puppycrawl.tools.checkstyle.checks.coding;

import java.*;
import java.util.*;
import org.antlr.v4.runtime.*;
import com.*;
//configuration "illegalClassNames": List
public class InputIllegalTypeStarImports
{
    List<Integer> l = new LinkedList<>(); //WARNING
}
