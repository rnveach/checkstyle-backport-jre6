package com.puppycrawl.tools.checkstyle.checks.annotation;

public class InputMissingDeprecated2 {


    /**
     * @deprecated
     * 
     * @param comment
     */
    public void method(){
    }

}
