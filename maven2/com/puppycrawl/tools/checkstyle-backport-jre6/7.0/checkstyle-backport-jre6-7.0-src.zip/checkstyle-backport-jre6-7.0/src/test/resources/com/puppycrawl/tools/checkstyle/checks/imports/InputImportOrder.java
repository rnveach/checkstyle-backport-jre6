package com.puppycrawl.tools.checkstyle.checks.imports;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Dialog;
import java.awt.event.ActionEvent;
import static java.awt.Button.ABORT
;
import javax.swing.JComponent;
import javax.swing.JTable;
import java.io.File;
import static java.io.File.createTempFile;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import static javax.swing.WindowConstants.*;

import static sun.tools.util.ModifierFilter.ALL_ACCESS;
import static sun.tools.util.ModifierFilter.PACKAGE;

public class InputImportOrder {
}
