package com.puppycrawl.tools.checkstyle.grammars.comments;
// my class
class InputComments2
{
    /**
     * Lines <b>method</b>.
     * 
     * @return string.
     */
    protected String line()
    {
		return null;
    }
}
