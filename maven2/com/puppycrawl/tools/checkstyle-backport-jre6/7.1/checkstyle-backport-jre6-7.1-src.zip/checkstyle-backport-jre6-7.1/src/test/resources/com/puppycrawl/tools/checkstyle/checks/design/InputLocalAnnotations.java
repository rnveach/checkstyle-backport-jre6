package com.puppycrawl.tools.checkstyle.checks.design;

public class InputLocalAnnotations
{
    public @interface Rule {
        
    }

    public @interface ClassRule {

    }
}
