/**
 * blah blah
 */
package com.puppycrawl.tools.checkstyle.checks.javadoc.pkginfo.invalidformat;
