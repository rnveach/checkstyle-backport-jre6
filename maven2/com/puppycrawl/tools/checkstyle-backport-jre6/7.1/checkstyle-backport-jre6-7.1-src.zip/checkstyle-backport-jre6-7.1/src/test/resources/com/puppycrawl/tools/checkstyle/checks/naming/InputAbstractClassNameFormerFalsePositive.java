package com.puppycrawl.tools.checkstyle.checks.naming;

public class InputAbstractClassNameFormerFalsePositive
{
    class Abstract {
        
    }
    
    class AbstractClass {
        
    }
}
