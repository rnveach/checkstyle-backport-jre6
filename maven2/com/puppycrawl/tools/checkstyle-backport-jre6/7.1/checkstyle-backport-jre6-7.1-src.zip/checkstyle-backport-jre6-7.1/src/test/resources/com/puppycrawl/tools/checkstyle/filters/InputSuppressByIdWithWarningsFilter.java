package com.puppycrawl.tools.checkstyle.filters;

public class InputSuppressByIdWithWarningsFilter {

    @SuppressWarnings("checkstyle:ignore")
    private int A1 = 1;

    @SuppressWarnings("checkstyle:ignore")
    public static void main(String[] args) {

    }

}
