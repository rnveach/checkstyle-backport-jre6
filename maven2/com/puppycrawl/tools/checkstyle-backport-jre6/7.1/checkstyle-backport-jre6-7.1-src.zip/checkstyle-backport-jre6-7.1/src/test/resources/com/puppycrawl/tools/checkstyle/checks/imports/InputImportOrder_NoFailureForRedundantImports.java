package com.puppycrawl.tools.checkstyle.checks.imports;

public class InputImportOrder_NoFailureForRedundantImports {
}

