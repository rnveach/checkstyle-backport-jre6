package com.puppycrawl.tools.checkstyle.checks.header;

import java.awt.*;

/**
 * Some doc.
 */

public class InputRegexpHeader1
{
}
