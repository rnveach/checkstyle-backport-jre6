package com.puppycrawl.tools.checkstyle.checks.whitespace;

import com.google.common.annotations.Beta;

import javax.accessibility.AccessibleAttributeSequence;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class InputNoLineWrapGood {
    
	public void fooMethod() {
		//
	}
}
